'use strict';

import 'isomorphic-fetch';
import './carbon.js';
const $ = jQuery;
const $document = $( document );
const $window = $( window );
