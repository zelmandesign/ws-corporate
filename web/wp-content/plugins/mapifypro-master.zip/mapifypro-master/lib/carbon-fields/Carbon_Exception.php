<?php

namespace Mpfy\Carbon;

class Carbon_Exception extends \Exception {
	
}


