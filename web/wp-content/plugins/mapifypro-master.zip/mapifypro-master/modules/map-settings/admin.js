(function($, $window, $document){
	$document.ready(function(){
		$('.add-new-h2, #delete-action').remove();
	});
})(jQuery, jQuery(window), jQuery(document));