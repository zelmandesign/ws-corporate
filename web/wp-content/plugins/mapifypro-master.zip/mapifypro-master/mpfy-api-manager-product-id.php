<?php

if ( ! defined( 'MAPIFY_AM_PRODUCT_ID' ) ) {
	define('MAPIFY_AM_PRODUCT_ID', 8672 );
}

