<?php
$versions = array(
	'2.3.2'=>'mpfy_mlqm_migrate',
	'3.2.0'=>'', // no updater
);
